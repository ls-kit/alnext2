
import Footer from "@/components/Layout/Footer";
import Navbar from "@/components/Layout/Navbar";
import React from "react";

const Login = () => {
  return (
    <>

      <div className="innovate-main-container">
        
        <div className="text-center lg:text-left">
          <h1 className="text-2xl font-bold">Login now!</h1>
        </div>
       
      </div>
    </>
  );
};

export default Login;
