import Footer from "@/components/Layout/Footer";
import Navbar from "@/components/Layout/Navbar";
import React from "react";

const Signup = () => {
  return <div>
    
    <div>
      <Navbar/>
      <Footer/>
    </div>
    
  </div>;
};

export default Signup;
